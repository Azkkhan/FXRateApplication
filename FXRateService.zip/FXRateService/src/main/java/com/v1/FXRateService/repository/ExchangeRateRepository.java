package com.v1.FXRateService.repository;

import com.v1.FXRateService.entity.ExchangeRate;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ExchangeRateRepository extends JpaRepository<ExchangeRate,Long> {

    Optional<ExchangeRate> findByDateAndSourceCurrencyAndTargetCurrency(LocalDate date, String sourceCurrency, String targetCurrency);

    List<ExchangeRate> findTop3BySourceCurrencyAndTargetCurrencyOrderByDateDesc(String sourceCurrency,
                                                                                String targetCurrency);
}
