package com.v1.FXRateService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FxRateServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
