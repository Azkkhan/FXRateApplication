package com.v1.FXRateService.entity;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "fxdatabase")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class ExchangeRate {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    @Column(name="DATE")
    private LocalDate date;

    @Column(name="SOURCE_CURRENCY")
    private String sourceCurrency;

    @Column(name="TARGET_CURRENCY")
    private String targetCurrency;

    @Column(name="RATE")
    private String rate;

}
