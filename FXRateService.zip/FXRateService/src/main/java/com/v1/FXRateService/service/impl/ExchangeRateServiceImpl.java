package com.v1.FXRateService.service.impl;

import com.v1.FXRateService.entity.ExchangeRate;
import com.v1.FXRateService.repository.ExchangeRateRepository;
import com.v1.FXRateService.service.ExchangeRateService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class ExchangeRateServiceImpl implements ExchangeRateService {

    @Value("${external.api.url}")
    private String apiUrl;

    private final ExchangeRateRepository repository;

    private final RestTemplate restTemplate;

    public ExchangeRateServiceImpl(ExchangeRateRepository repository, RestTemplateBuilder restTemplate) {
        this.repository = repository;
        this.restTemplate = restTemplate.build();
    }

    @Transactional
    @Override
    public ExchangeRate getExchangeRate(String targetCurrency){
        LocalDate today=
                LocalDate.now();
        return repository.findByDateAndSourceCurrencyAndTargetCurrency(today,"USD",targetCurrency)
                .orElseGet(()->fetchAndSaveRate(today,targetCurrency));
    }

    private ExchangeRate fetchAndSaveRate(LocalDate date,String targetCurrency){
            String url= String.format("%s/%s?to=$s",apiUrl,date,targetCurrency);
            Map<String,Object> response=restTemplate.getForObject(url, Map.class);
            Map<String,Object> rates=(Map<String,Object>) response.get("rates");
            String rate=rates.get(targetCurrency).toString();
            ExchangeRate exchangeRate=new ExchangeRate();
            exchangeRate.setDate(date);
            exchangeRate.setSourceCurrency("USD");
            exchangeRate.setTargetCurrency(targetCurrency);
            exchangeRate.setRate(rate);

            return repository.save(exchangeRate);

    }

    @Transactional
    @Override
    public List<ExchangeRate> getLatestEXchangeRates(String targetCurrency){
        return repository
                .findTop3BySourceCurrencyAndTargetCurrencyOrderByDateDesc("USD",targetCurrency);
    }
}
