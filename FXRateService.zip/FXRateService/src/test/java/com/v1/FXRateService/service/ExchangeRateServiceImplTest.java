package com.v1.FXRateService.service;

import com.v1.FXRateService.entity.ExchangeRate;
import com.v1.FXRateService.repository.ExchangeRateRepository;
import com.v1.FXRateService.service.impl.ExchangeRateServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class ExchangeRateServiceImplTest {

    @Autowired
    private ExchangeRateServiceImpl exchangeRateService;

    @MockBean
    private ExchangeRateRepository repository;

    @MockBean
    private RestTemplate restTemplate;

    @Test
    public void testGetExchangeRate(){
        LocalDate today=LocalDate.now();
        ExchangeRate exchangeRate=new ExchangeRate();

        exchangeRate.setDate(today);
        exchangeRate.setSourceCurrency("USD");
        exchangeRate.setTargetCurrency("EUR");
        exchangeRate.setRate("0.85");

        Mockito.when(repository
                .findByDateAndSourceCurrencyAndTargetCurrency(today,"USD","EUR"))
                .thenReturn(Optional.of(exchangeRate));
        ExchangeRate fetchedRate=exchangeRateService.getExchangeRate("EUR");

        assertThat(fetchedRate.getRate()).isEqualTo("0.85");
    }

    @Test
    public void testGetLatestEchangeRates(){
        ExchangeRate exchangeRate=new ExchangeRate();

        exchangeRate.setDate(LocalDate.now().minusDays(1));
        exchangeRate.setSourceCurrency("USD");
        exchangeRate.setTargetCurrency("EUR");
        exchangeRate.setRate("0.85");

        Mockito.when(repository
                .findTop3BySourceCurrencyAndTargetCurrencyOrderByDateDesc("USD","EUR"))
                .thenReturn(Collections.singletonList(exchangeRate));

        assertThat(exchangeRateService.getLatestEXchangeRates("EUR")).hasSize(1);
    }
}
