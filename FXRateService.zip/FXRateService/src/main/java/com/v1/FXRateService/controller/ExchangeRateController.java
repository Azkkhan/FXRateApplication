package com.v1.FXRateService.controller;

import com.v1.FXRateService.entity.ExchangeRate;
import com.v1.FXRateService.service.impl.ExchangeRateServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController()
@RequestMapping("/fx")
public class ExchangeRateController {


    @Autowired
    private final ExchangeRateServiceImpl service;

    public ExchangeRateController(ExchangeRateServiceImpl service) {
        this.service = service;
    }

    @GetMapping
    public ExchangeRate getExchangeRate(@RequestParam String targetCurrency){
        return service.getExchangeRate(targetCurrency);
    }

    @GetMapping("/{targetcurrency}")
    public List<ExchangeRate> getLatestExchangeRates(@PathVariable String targetCurrency){
        return service.getLatestEXchangeRates(targetCurrency);
    }
}
