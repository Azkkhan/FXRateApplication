package com.v1.FXRateService.service;

import com.v1.FXRateService.entity.ExchangeRate;

import java.util.List;

public interface ExchangeRateService {

    public ExchangeRate getExchangeRate(String targetCurrency);

    public List<ExchangeRate> getLatestEXchangeRates(String targetCurrency);
}
